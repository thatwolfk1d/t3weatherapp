'''
Created on Nov 30, 2022

@author: franciscolopez
'''
import os
from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy
from weather_apis import get_current_forecast, get_hourly_forecast
from flask_login import (UserMixin, LoginManager, login_user, logout_user, login_required,
current_user)



basedir = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)

# initializes Database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'Users.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = "create-secret-key"

db = SQLAlchemy(app)

# initializes Users table
class Users(UserMixin, db.Model):
    '''
    Users class creates Users table for database
    '''
    __tablename__ = "Users"
    id = db.Column(db.Integer, primary_key=True) # pylint: disable=no-member
    first_name = db.Column(db.String(100)) # pylint: disable=no-member
    last_name = db.Column(db.String(100)) # pylint: disable=no-member
    username = db.Column(db.String(100)) # pylint: disable=no-member
    email = db.Column(db.String(100)) # pylint: disable=no-member
    password = db.Column(db.String()) # pylint: disable=no-member

    def __init__(self, first_name, last_name, username, email, password):
        self.first_name = first_name
        self.last_name = last_name
        self.username = username
        self.email = email
        self.password = password

# creates Database and Users Table
with app.app_context():
    db.create_all()

# create login manager to track whether or not a user is signed in
login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)

@login_manager.user_loader
def load_user(user_id):
    """Determines if passed value contains a dictionary"""
    return Users.query.get(int(user_id))

def is_dict(value):
    """Checks if a value is a dictionary"""
    return isinstance(value,dict)

@app.route('/login', methods = ['GET', 'POST'])
def login():
    '''
    renders the login page
    '''
    if request.method == 'POST':
        # retrieve form input
        username = request.form['username']
        password = request.form['password']

        # retrieve username and password from database
        verify_user = Users.query.filter_by(username=username).first()

        if verify_user:
            if check_password_hash(verify_user.password, password):
                flash('Login Successful')
                login_user(verify_user)
                return redirect(url_for('home'))

            flash('Username or password is incorrect')
            return redirect(url_for('login'))

        flash('User does not exist')
        return redirect(url_for('login'))

    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    '''
    logs user out of account
    '''
    flash('Logout Successful')
    logout_user()
    return redirect(url_for('home'))

@app.route('/passwordreset', methods = ['GET', 'POST'])
@login_required
def password_reset():
    '''
    renders password reset page
    '''
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        new_password = request.form['new_password']

        user = Users.query.filter_by(username=username).first()

        if user:
            if check_password_hash(user.password, password):
                new_password = generate_password_hash(new_password, method='sha256')
                user.password = new_password
                db.session.commit() # pylint: disable=no-member
                return redirect(url_for('login'))
        flash('Password Rest Failed. Try Again')
        return redirect(url_for('reset'))
    return render_template('reset.html')

@app.route('/profile')
@login_required
def profile():
    '''
    renders profile page if user is signed in
    '''
    return render_template('profile.html', name = current_user.first_name)

@app.route('/register', methods = ['GET', 'POST'])
def register():
    '''
    renders the Registration Page
    '''
    if request.method == 'POST':
        # retrieve form input
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        email = request.form['email']
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        # retrieves existing user from database if one exists
        user_email = Users.query.filter_by(email=email).first()
        user_name = Users.query.filter_by(username=username).first()

        # checks if email exists in database
        if user_email:
            flash('Email already in use')
            return redirect(url_for('register'))

        # checks if username exists in database
        if user_name:
            flash('Username already in use')
            return redirect(url_for('register'))

        # checks if given passwords match
        if password != confirm_password:
            flash('Passwords do not match')
            return redirect(url_for('register'))

        # hashes given password
        password = generate_password_hash(password, method='sha256')

        # create new user with input from registration page
        new_user = Users(first_name, last_name, username, email, password)

        # add user to table and commit changes
        db.session.add(new_user) # pylint: disable=no-member
        db.session.commit() # pylint: disable=no-member
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/search', methods = ['GET', 'POST'])
def search():
    '''
    renders the search page
    '''

    if request.method == 'POST':
        city_zip = request.form['city_zip']
        country = request.form['country']
        return redirect(url_for('home', city_zip=city_zip,country=country))
    return render_template('search.html')

@app.route('/query', methods = ['GET', 'POST'])
def query():
    '''
    renders the search results
    '''
    ################################
    #Code to return list of items to be passed to query page to be displayed
    ###############################

    return render_template('query.html')

@app.route('/', methods = ['GET', 'POST'])
def home():
    '''
    renders the home page
    '''
    city_zip = request.args.get('city_zip','New York')
    country = request.args.get('country','US')
    if request.method == 'GET':
        location = get_current_forecast(city_zip,country)
        ##try:
            #print(location['name'] + location['sys']['country'])
        ##except: # pylint: disable=bare-except
           ## flash("Invalid search criteria, could not retrieve any results")
            ##return redirect(url_for('search'))

        return render_template('home.html',location=location,city_zip=city_zip,country=country)
    return render_template('home.html',location=location,city_zip=city_zip,country=country)


@app.route('/utility_one', methods = ['GET', 'POST'])
def utility_one():
    """
    Utility page to refresh home page
    """
    city_zip = request.args.get('city_zip','New York')
    country = request.args.get('country','US')
    if request.method == 'GET':
        location = get_hourly_forecast(city_zip,country)
        return render_template('home.html',location=location)
    return render_template('home.html',location=location,city_zip=city_zip,country=country)

if __name__ == '__main__':
    app.run()
