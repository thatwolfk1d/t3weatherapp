'''
Created on Nov 30, 2022

@author: franciscolopez
'''
import os
from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy
from WeatherAPIs import get_location, get_current_forecast


basedir = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)

# initializes Database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'Users.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = "create-secret-key"

db = SQLAlchemy(app)

# initializes Users table
class Users(db.Model):
    '''
    Users class creates Users table for database
    '''
    __tablename__ = "Users"
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(100))
    last_name = db.Column(db.String(100))
    username = db.Column(db.String(100))
    email = db.Column(db.String(100))
    password = db.Column(db.String())

    def __init__(self, first_name, last_name, username, email, password):
        self.first_name = first_name
        self.last_name = last_name
        self.username = username
        self.email = email
        self.password = password

# creates Database and Users Table
with app.app_context():
    db.create_all()

def is_dict(value):
    """Checks if a value is a dictionary"""
    return isinstance(value,dict)

@app.route('/login', methods = ['GET', 'POST'])
def login():
    '''
    renders the login page
    '''
    if request.method == 'POST':
        # retrieve form input
        username = request.form['username']
        password = request.form['password']

        # retrieve username and password from database
        verify_user = Users.query.filter_by(username=username).first()

        if verify_user:
            if check_password_hash(verify_user.password, password):
                flash('Login Successful')
                return redirect(url_for('home'))

            flash('Username or password is incorrect')
            return redirect(url_for('login'))

        flash('User does not exist')
        return redirect(url_for('login'))

    return render_template('login.html')

@app.route('/register', methods = ['GET', 'POST'])
def register():
    '''
    renders the Registration Page
    '''
    if request.method == 'POST':
        # retrieve form input
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        email = request.form['email']
        username = request.form['username']
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        # retrieves existing user from database if one exists
        user_email = Users.query.filter_by(email=email).first()
        user_name = Users.query.filter_by(username=username).first()

        # checks if email exists in database
        if user_email:
            flash('Email already in use')
            return redirect(url_for('register'))

        # checks if username exists in database
        if user_name:
            flash('Username already in use')
            return redirect(url_for('register'))

        # checks if given passwords match
        if password != confirm_password:
            flash('Passwords do not match')
            return redirect(url_for('register'))

        # hashes given password
        password = generate_password_hash(password, method='sha256')

        # create new user with input from registration page
        new_user = Users(first_name, last_name, username, email, password)

        # add user to table and commit changes
        db.session.add(new_user)
        db.session.commit()
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/search', methods = ['GET', 'POST'])
def search():
    '''
    renders the search page
    '''

    if request.method == 'POST':
        city_zip = request.form['city_zip']
        country = request.form['country']
        return redirect(url_for('home', city_zip=city_zip,country=country))
    return render_template('search.html')

@app.route('/query', methods = ['GET', 'POST'])
def query():
    '''
    renders the search results
    '''
    ################################
    #Code to return list of items to be passed to query page to be displayed
    ###############################

    return render_template('query.html')

@app.route('/', methods = ['GET', 'POST'])
def home():
    '''
    renders the home page
    '''
    city_zip = request.args.get('city_zip','10282')
    country = request.args.get('country','US')
    if request.method == 'GET':
        location = get_current_forecast(city_zip,country)
        return render_template('home.html',location=location)
    return render_template('home.html',location=location)

if __name__ == '__main__':
    app.run()
