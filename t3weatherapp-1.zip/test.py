from WeatherAPIs import get_current_forecast,get_location

print(get_location("20634","US"))
print(get_current_forecast("20620","US"))